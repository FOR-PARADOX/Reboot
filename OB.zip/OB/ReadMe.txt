Hey, Pure here. First off. Thanks for using the Paradox Mod version of OpenBullet.
Here some tips to  keep your installation running smoothly. 

Keep the Files Formatted this way, The Updater works best if you run it in this folder. 

It also works best if you keep the File Hierarchy the same. like this. OB/Release.

If you move files around then the updater will not automatically overwrite files.

Thanks for reading, 

--Pure